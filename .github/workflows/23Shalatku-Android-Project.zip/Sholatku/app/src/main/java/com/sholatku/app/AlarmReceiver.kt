package com.sholatku.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Calendar

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        var started = false
        try {
            ContextCompat.startForegroundService(
                context,
                Intent(context, PrayerService::class.java).setAction(PrayerService.ACT_TICK)
            )
            started = true
        } catch (e: Exception) {
        }
        // Cadangan: bila sistem menolak layanan dijalankan, azan/iqomah tetap berbunyi lewat notifikasi.
        if (!started) fallback(context)
    }

    private fun fallback(c: Context) {
        try {
            val now = System.currentTimeMillis()
            val ev = PrayerTimes.events(Store.cfg(c), Calendar.getInstance()).firstOrNull {
                (it.kind == "a" || it.kind == "i") &&
                    now >= it.whenMs && now < it.whenMs + (if (it.kind == "a") 180000L else 90000L)
            } ?: return
            val isAzan = ev.kind == "a"
            val chId = if (isAzan) "azan_fb" else "iqomah_fb"
            val raw = if (isAzan) R.raw.azan else R.raw.iqomah
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(
                chId,
                if (isAzan) "Azan (cadangan)" else "Iqomah (cadangan)",
                NotificationManager.IMPORTANCE_HIGH
            )
            ch.setSound(
                Uri.parse("android.resource://" + c.packageName + "/" + raw),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            ch.enableVibration(true)
            nm.createNotificationChannel(ch)
            val name = PrayerTimes.NAMES[ev.key] ?: ev.key
            val open = PendingIntent.getActivity(
                c, 103, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val n = NotificationCompat.Builder(c, chId)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(if (isAzan) "AZAN BERKUMANDANG" else "IQOMAH")
                .setContentText("Waktu " + name + " · " + PrayerTimes.fmt(ev.minute))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
            nm.notify(3, n)
        } catch (e: Exception) {
        }
    }
}
